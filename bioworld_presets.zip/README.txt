Bioworld Presets Pack
---------------------
Files:
- Five JSON preset rows for the Generator.
- preset_guidance.csv with aesthetic + metric targets.

Usage:
1) Upload JSON + CSV to your GPT Knowledge or the Generator's catalog folder.
2) Point the Generator at a JSON (preset_id) and run the desired pipeline.
3) The Validator enforces budgets listed in each JSON and metrics_targets from the CSV.
